//
//  ReminderVC.swift
//  ReminderDemo
//
//  Created by admin on 8/5/19.
//  Copyright © 2019 admin. All rights reserved.
//

import UIKit
import CoreData

class ReminderVC: UIViewController {

    @IBOutlet weak var tblReminder: UITableView!{
        didSet{
            tblReminder.dataSource = self
            tblReminder.delegate = self
            tblReminder.tableFooterView = UIView()
        }
    }
    
    @IBOutlet weak var viewReminder: UIView!
    @IBOutlet weak var txtReminder: UITextView!{
        didSet{
            txtReminder.placeholder = "Add Text Here"
            txtReminder.layer.borderWidth = 1.0
            txtReminder.layer.borderColor = UIColor(red: 220/255.0, green: 220/255.0, blue: 220/255.0, alpha: 1.0).cgColor
        }
    }
    @IBOutlet weak var txtDate: UITextField!{
        didSet{
            let startPickerview =  UIDatePicker()
            startPickerview.datePickerMode = .dateAndTime
            startPickerview.addTarget(self, action: #selector(startDate(_:)), for: UIControl.Event.valueChanged)
            txtDate.inputView = startPickerview
            
            
        }
    }
    
    let appDelegate = UIApplication.shared.delegate as? AppDelegate
    var moc:NSManagedObjectContext!
    var reminderList = [Reminders]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        moc = appDelegate?.persistentContainer.viewContext
        loadData()
    }
    
    @objc func startDate(_ sender: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd MMM, yyyy HH:mm:ss"
        txtDate.text = formatter.string(from: sender.date)
    }
    
    @IBAction func onClickAdd(_ sender: Any) {
        if txtDate.text == ""{
            UIApplication.alert(title: "", message: "please select date to set reminder")
        }else if txtReminder.text == ""{
            UIApplication.alert(title: "", message: "please enter text reminder")
        }else{
            let reminder = Reminders(context: moc)
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd MMM, yyyy HH:mm:ss"
            reminder.reminder_date = dateFormatter.date(from: txtReminder.text)
            reminder.reminder_string = txtReminder.text
            appDelegate?.saveContext()
            loadData()
            viewReminder.isHidden = true
            txtDate.text = nil
            txtReminder.text = nil

        }
        
    }
    
    func loadData(){
        // 1
        let reminderRequest:NSFetchRequest<Reminders> = Reminders.fetchRequest()
        
        // 2
        let sortDescriptor = NSSortDescriptor(key: "reminder_date", ascending: false)
        reminderRequest.sortDescriptors = [sortDescriptor]
        
        // 3
        do {
            try reminderList = moc.fetch(reminderRequest)
        }catch {
            print("Could not load data")
        }
        
        // 4
        self.tblReminder.reloadData()
    }
    
    @IBAction func onClickCancel(_ sender: Any) {
        viewReminder.isHidden = true
    }
    
    @IBAction func onClickAddReminder(_ sender: Any) {
        viewReminder.isHidden = false
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension ReminderVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ReminderCell") as? ReminderCell else {
            fatalError("Cell can't be dequeue")
        }
        
        let reminder = reminderList[indexPath.row]
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM, yyyy HH:mm:ss"
        cell.lblDate.text = dateFormatter.string(from: reminder.reminder_date ?? Date())
        cell.btnDelete.tag = indexPath.row
        cell.btnDelete.addTarget(self, action: #selector(onClickDelete(_:)), for: .touchUpInside)
        cell.lblText.text = reminder.reminder_string
        return cell
    }
    
    @objc func onClickDelete(_ sender:UIButton){
       
        moc.delete(reminderList[sender.tag])
        reminderList.remove(at: sender.tag)
        appDelegate?.saveContext()
        loadData()
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reminderList.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
    }
    
}
